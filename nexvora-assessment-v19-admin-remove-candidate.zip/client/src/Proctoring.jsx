import React,{useEffect,useRef,useState} from 'react';
import {FaceLandmarker,FilesetResolver} from '@mediapipe/tasks-vision';
import {io} from 'socket.io-client';

const MODEL='https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task';
const WASM='https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.22/wasm';

export default function Proctoring({attempt,onViolation,onStatus,onAdminTerminate}){
 const videoRef=useRef(null),streamRef=useRef(null),landmarkerRef=useRef(null),rafRef=useRef(null),audioRef=useRef(null),socketRef=useRef(null),peersRef=useRef(new Map());
 const [camera,setCamera]=useState('starting'),[mic,setMic]=useState('starting'),[gaze,setGaze]=useState('checking'),[voice,setVoice]=useState(false),[live,setLive]=useState('connecting');
 const state=useRef({last:{},faceSince:0,gazeSince:0,voiceSince:0,lastFrame:0,headAwaySince:0,started:false});
 const beep=()=>{try{const C=window.AudioContext||window.webkitAudioContext;if(!C)return;const a=new C(),o=a.createOscillator(),g=a.createGain();o.frequency.value=880;g.gain.value=.05;o.connect(g);g.connect(a.destination);o.start();o.stop(a.currentTime+.12);o.onended=()=>a.close()}catch{}};
 const violation=(reason,cooldown=6000)=>{const now=Date.now();if(now-(state.current.last[reason]||0)<cooldown)return;state.current.last[reason]=now;beep();onViolation(reason)};
 useEffect(()=>{
  let mounted=true;
  const cleanup=()=>{mounted=false;if(rafRef.current)cancelAnimationFrame(rafRef.current);try{landmarkerRef.current?.close()}catch{};streamRef.current?.getTracks().forEach(t=>t.stop());try{audioRef.current?.ac?.close()}catch{};try{socketRef.current?.disconnect()}catch{};peersRef.current.forEach(pc=>pc.close());peersRef.current.clear();landmarkerRef.current=null};
  const onFs=()=>{if(mounted && document.fullscreenElement===null)violation('fullscreen_exit',8000)};
  document.addEventListener('fullscreenchange',onFs);
  async function start(){
   try{
    if(!navigator.mediaDevices?.getUserMedia)throw Error('Camera/microphone are not supported. Use the latest Chrome or Edge.');
    const stream=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:640},height:{ideal:480},facingMode:'user'},audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
    if(!mounted){stream.getTracks().forEach(t=>t.stop());return}
    streamRef.current=stream;setCamera('on');setMic('on');
    const socket=io(window.location.origin,{auth:{token:localStorage.getItem('token')}}); socketRef.current=socket;
    socket.on('connect',()=>{socket.emit('candidate:join',{attemptId:attempt});setLive('ready')});
    socket.on('connect_error',()=>setLive('unavailable'));
    socket.on('admin:terminated',({reason})=>{onStatus?.('Assessment terminated by admin: '+(reason||'suspected cheating'));try{stream.getTracks().forEach(t=>t.stop())}catch{};setLive('terminated');onAdminTerminate?.(reason||'Assessment terminated by admin for suspected cheating')});
    socket.on('viewer:joined',async({viewerId})=>{try{const pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});peersRef.current.set(viewerId,pc);stream.getTracks().forEach(t=>pc.addTrack(t,stream));pc.onicecandidate=e=>{if(e.candidate)socket.emit('candidate:ice',{viewerId,candidate:e.candidate})};const offer=await pc.createOffer();await pc.setLocalDescription(offer);socket.emit('candidate:offer',{viewerId,offer:pc.localDescription});}catch(e){setLive('error')}});
    socket.on('viewer:answer',async({viewerId,answer})=>{const pc=peersRef.current.get(viewerId);if(pc)await pc.setRemoteDescription(answer).catch(()=>{})});
    socket.on('viewer:ice',async({viewerId,candidate})=>{const pc=peersRef.current.get(viewerId);if(pc&&candidate)await pc.addIceCandidate(candidate).catch(()=>{})});
    socket.on('viewer:left',({viewerId})=>{const pc=peersRef.current.get(viewerId);if(pc)pc.close();peersRef.current.delete(viewerId)});
    if(videoRef.current){videoRef.current.srcObject=stream;await videoRef.current.play().catch(()=>{});}
    onStatus?.('Camera + microphone connected. Face monitoring is active.');

    const AC=window.AudioContext||window.webkitAudioContext;
    if(AC){
      const ac=new AC();const src=ac.createMediaStreamSource(stream),an=ac.createAnalyser();an.fftSize=1024;an.smoothingTimeConstant=.15;src.connect(an);audioRef.current={ac,an};
      const data=new Uint8Array(an.fftSize);
      const audioLoop=()=>{if(!mounted)return;an.getByteTimeDomainData(data);let sum=0;for(const v of data){const x=(v-128)/128;sum+=x*x}const rms=Math.sqrt(sum/data.length);const active=rms>.055;setVoice(active);
       if(active){if(!state.current.voiceSince)state.current.voiceSince=Date.now();if(Date.now()-state.current.voiceSince>1400)violation('voice_detected',8000)}else state.current.voiceSince=0;
       requestAnimationFrame(audioLoop)};audioLoop();
    }

    onStatus?.('Loading face/eye detector…');
    const vision=await FilesetResolver.forVisionTasks(WASM);
    const lm=await FaceLandmarker.createFromOptions(vision,{baseOptions:{modelAssetPath:MODEL,delegate:'GPU'},runningMode:'VIDEO',numFaces:1,minFaceDetectionConfidence:.55,minFacePresenceConfidence:.55,minTrackingConfidence:.55});
    if(!mounted){lm.close();return}landmarkerRef.current=lm;state.current.started=true;onStatus?.('Monitoring active — keep your face visible and look at the screen.');

    const loop=(t)=>{if(!mounted)return;rafRef.current=requestAnimationFrame(loop);if(t-state.current.lastFrame<100)return;state.current.lastFrame=t;const v=videoRef.current;if(!v||v.readyState<2)return;
      try{
       const res=lm.detectForVideo(v,t);const face=res.faceLandmarks?.[0];
       if(!face){setGaze('no-face');if(!state.current.faceSince)state.current.faceSince=Date.now();if(Date.now()-state.current.faceSince>1200)violation('face_missing',7000);return}
       state.current.faceSince=0;
       // Estimate head turn from nose position relative to the eye corners.
       const p=i=>face[i];const nose=p(1),le=p(33),re=p(263),eyeMidX=(le.x+re.x)/2,eyeWidth=Math.max(.05,Math.abs(re.x-le.x));
       const headOffset=(nose.x-eyeMidX)/eyeWidth;
       const headAway=Math.abs(headOffset)>.38;
       // Iris ratio for both eyes. Values near 0/1 mean looking strongly sideways.
       const iris=(ids)=>{let x=0;ids.forEach(i=>x+=p(i).x);return x/ids.length};
       const li=iris([468,469,470,471,472]),ri=iris([473,474,475,476,477]);
       const lmin=Math.min(p(33).x,p(133).x),lmax=Math.max(p(33).x,p(133).x);const rmin=Math.min(p(263).x,p(362).x),rmax=Math.max(p(263).x,p(362).x);
       const lr=(li-lmin)/Math.max(.001,lmax-lmin),rr=(ri-rmin)/Math.max(.001,rmax-rmin),eye=(lr+rr)/2;
       const eyeAway=eye<.20||eye>.80;
       const away=headAway||eyeAway;
       setGaze(away?'away':'focused');
       if(away){if(!state.current.gazeSince)state.current.gazeSince=Date.now();if(Date.now()-state.current.gazeSince>1600)violation(headAway?'head_turned_away':'gaze_away',8000)}else state.current.gazeSince=0;
      }catch(e){onStatus?.('Face detector error. Keep the camera active and your face visible.');}
    };
    rafRef.current=requestAnimationFrame(loop);
   }catch(e){setCamera('blocked');setMic('blocked');onStatus?.(e?.message||'Camera and microphone permission is required. Please allow both and restart the assessment.')}
  }
  start();
  return()=>{document.removeEventListener('fullscreenchange',onFs);cleanup()};
 },[attempt]);
 return <div className="proctorbox card"><video ref={videoRef} muted playsInline autoPlay className="proctorvideo"/><div className="proctorstatus"><span>📷 {camera==='on'?'Camera ON':camera==='blocked'?'Camera blocked':'Camera '+camera}</span><span>🎙️ {mic==='on'?'Mic ON':mic==='blocked'?'Mic blocked':'Mic '+mic}</span><span>👁️ {gaze==='focused'?'Eyes focused':gaze==='away'?'Looking away':gaze==='no-face'?'Face not detected':'Checking eyes…'}</span><span>🔊 {voice?'Voice detected':'No voice'}</span><span>📡 {live==='ready'?'Admin live link ON':live==='unavailable'?'Admin live link unavailable':'Admin live '+live}</span></div></div>
}
